// This file is intentionally left empty.
// The Devnet Beta app is now loaded via Iframe to ensure robust navigation support.
