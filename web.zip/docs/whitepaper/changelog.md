# Whitepaper Changelog

## v0.1
- Documentation site online
- Initial public structure and placeholders

## Next
- v0.2: detailed system model, data format, timing windows
- v0.3: oracle/settlement flow + threat model summary
