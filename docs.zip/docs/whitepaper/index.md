# Whitepaper

This section hosts the **canonical web version** of the TIMLG Protocol whitepaper.

## Read formats

- **Web:** this documentation site (recommended for navigation)
- **PDF:** [whitepaper_TIMLG_v0.1.pdf](../assets/whitepaper_TIMLG_v0.1.pdf)

!!! tip
    If you update the PDF, keep the filename stable (or update the link in `mkdocs.yml`).
