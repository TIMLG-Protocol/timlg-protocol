# Whitepaper Changelog

## v0.1
- Initial public documentation structure.
- High-level protocol overview and documentation site online.

## Planned
- v0.2: refined system model, threat model, and oracle/settlement details.
- v0.3: tokenomics finalization and treasury/BitIndex specification alignment.
