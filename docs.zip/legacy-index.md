# Welcome to TIMLG Protocol

TIMLG is a verifiable time-log protocol for reproducible coordination.

## Start here
- **Status:** /docs/status/status.md
- **Roadmap:** /docs/roadmap/roadmap.md
- **Specs:** /docs/specs/
- **Repository:** This site is the public documentation hub.
