# timlg-protocol
TIMLG Protocol — verifiable time-log coordination for reproducible research.
